import type { Metadata } from 'next';
import { Fraunces, Manrope } from 'next/font/google';

import { ThemeProvider } from '@/components/theme-provider';

import './globals.css';

const fraunces = Fraunces({
  variable: '--font-fraunces',
  subsets: ['latin'],
  display: 'swap',
});

const manrope = Manrope({
  variable: '--font-manrope',
  subsets: ['latin'],
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000',
  ),
  title: 'Delícias Rosicleia — comida caseira, direto no seu iFood',
  description:
    'Comida feita à moda da casa, com ingredientes selecionados. Veja o cardápio completo e peça pelo iFood.',
  icons: {
    icon: '/favicon.svg',
  },
  openGraph: {
    title: 'Delícias Rosicleia',
    description:
      'Comida feita à moda da casa. Cardápio completo e pedido pelo iFood.',
    type: 'website',
    images: [
      {
        url: '/og.png',
        width: 1200,
        height: 630,
        alt: 'Delícias Rosicleia — comida caseira, direto no seu iFood',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Delícias Rosicleia',
    description:
      'Comida feita à moda da casa. Cardápio completo e pedido pelo iFood.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className={`${manrope.variable} ${fraunces.variable}`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
