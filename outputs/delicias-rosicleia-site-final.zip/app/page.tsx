import { AtSign, Clock3 } from 'lucide-react';
import Image from 'next/image';

import { MenuCatalog } from '@/components/menu-catalog';
import { SiteHeader } from '@/components/site-header';
import { FlowButton } from '@/components/ui/flow-button';
import { HeroParallax } from '@/components/ui/hero-parallax';
import {
  descricaoVisivel,
  horarios,
  IFOOD_LINK,
  nomeVisivel,
  precoVisivel,
  produtos,
} from '@/lib/site-data';

const diasSchema: Record<string, string> = {
  'Segunda-feira': 'https://schema.org/Monday',
  'Terça-feira': 'https://schema.org/Tuesday',
  'Quarta-feira': 'https://schema.org/Wednesday',
  'Quinta-feira': 'https://schema.org/Thursday',
  'Sexta-feira': 'https://schema.org/Friday',
  Sábado: 'https://schema.org/Saturday',
  Domingo: 'https://schema.org/Sunday',
};

const openingHoursSpecification = horarios.flatMap(({ dia, faixas }) =>
  faixas.map((faixa) => {
    const [opens, closes] = faixa.split('–');

    return {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: diasSchema[dia],
      opens,
      closes,
    };
  }),
);

const structuredData = {
  '@context': 'https://schema.org',
  '@type': 'FoodEstablishment',
  name: 'Delícias Rosicleia',
  url: IFOOD_LINK,
  openingHoursSpecification,
};

export default function Home() {
  const destaque = produtos[0];

  return (
    <>
      <SiteHeader />
      <main>
        <HeroParallax />

        <section
          aria-labelledby="destaque-title"
          className="border-b border-gold-light/70 bg-surface py-20 sm:py-24"
        >
          <div className="mx-auto w-[min(1180px,calc(100%-32px))]">
            <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <h2
                id="destaque-title"
                className="max-w-[13ch] font-heading text-[clamp(2.25rem,4.7vw,3.75rem)] leading-[1.04] tracking-[-0.045em]"
              >
                Destaque da semana
              </h2>
              <p className="max-w-md text-sm leading-6 text-muted md:text-right">
                Espaço reservado para a escolha especial da Rosicleia assim que
                o cardápio oficial for confirmado.
              </p>
            </div>

            <article className="grid overflow-hidden rounded-[6px] border border-gold-light/75 bg-background md:grid-cols-[1.35fr_1fr]">
              <div className="min-h-72 overflow-hidden border-b border-gold-light/70 md:min-h-[28rem] md:border-b-0 md:border-r">
                <Image
                  src={destaque.imagem}
                  alt={`Imagem provisória de ${nomeVisivel(destaque).toLocaleLowerCase('pt-BR')}`}
                  width="1200"
                  height="900"
                  priority
                  sizes="(max-width: 767px) 100vw, 57vw"
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="flex flex-col justify-between p-7 sm:p-10">
                <div>
                  <p className="text-sm font-semibold text-gold-ink">
                    Seleção em atualização
                  </p>
                  <h3 className="mt-4 text-2xl font-semibold tracking-[-0.025em] sm:text-3xl">
                    {nomeVisivel(destaque)}
                  </h3>
                  <p className="mt-5 max-w-[42ch] leading-7 text-muted">
                    {descricaoVisivel(destaque)}
                  </p>
                </div>

                <div className="mt-12 border-t border-gold-light/70 pt-6">
                  <p className="text-sm font-semibold text-muted">Valor</p>
                  <p className="mt-1 text-lg font-bold text-gold-ink">
                    {precoVisivel(destaque.preco)}
                  </p>
                </div>
              </div>
            </article>
          </div>
        </section>

        <MenuCatalog />
      </main>

      <footer
        id="horarios"
        className="scroll-mt-20 border-t border-gold-light/65 bg-[#2b2216] py-16 text-[#f2e9d8] dark:bg-[#0e0c08]"
      >
        <div className="mx-auto grid w-[min(1180px,calc(100%-32px))] gap-12 lg:grid-cols-[0.8fr_1.4fr_0.8fr]">
          <div>
            <p className="font-heading text-3xl tracking-[-0.035em]">
              Delícias Rosicleia
            </p>
            <p className="mt-4 max-w-[34ch] text-sm leading-6 text-[#d7cbb6]">
              Uma vitrine simples para conhecer o cardápio e pedir pelo canal
              oficial no iFood.
            </p>
          </div>

          <section aria-labelledby="horarios-title">
            <div className="flex items-center gap-3">
              <Clock3 aria-hidden="true" className="size-5 text-[#d9b15f]" />
              <h2 id="horarios-title" className="text-lg font-bold">
                Horários de funcionamento
              </h2>
            </div>

            <ul className="mt-6 grid gap-x-8 gap-y-3 sm:grid-cols-2">
              {horarios.map(({ dia, faixas }) => (
                <li
                  key={dia}
                  className="flex items-start justify-between gap-4 border-b border-[#f0d9a0]/20 pb-3 text-sm"
                >
                  <span className="font-semibold">{dia}</span>
                  <span className="text-right leading-5 text-[#d7cbb6]">
                    {faixas.map((faixa) => (
                      <span key={faixa} className="block">
                        {faixa}
                      </span>
                    ))}
                  </span>
                </li>
              ))}
            </ul>
          </section>

          <div className="lg:justify-self-end">
            <FlowButton
              className="border-[#d9b15f] text-[#f0d9a0] hover:text-[#2b2216]"
              text="Peça no iFood"
            />
            <div className="mt-7 flex items-center gap-3 text-sm text-[#d7cbb6]">
              <AtSign aria-hidden="true" className="size-[18px] text-[#d9b15f]" />
              <span>Redes sociais — em breve</span>
            </div>
          </div>
        </div>

        <div className="mx-auto mt-12 flex w-[min(1180px,calc(100%-32px))] flex-col gap-2 border-t border-[#f0d9a0]/20 pt-6 text-xs text-[#b8a98c] sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Delícias Rosicleia.</p>
          <p>Pedidos e pagamentos são concluídos exclusivamente no iFood.</p>
        </div>
      </footer>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
    </>
  );
}
