export const IFOOD_LINK =
  'https://www.ifood.com.br/delivery/sao-paulo-sp/delicias-rosicleia-conjunto-habitacional-brigadeiro-faria-lima/47694be2-a16e-49d2-9ba6-fbdaa2efe570?utm_medium=share';

export const horarios = [
  { dia: 'Segunda-feira', faixas: ['11:00–15:00', '18:00–23:00'] },
  { dia: 'Terça-feira', faixas: ['11:10–19:04'] },
  { dia: 'Quarta-feira', faixas: ['11:00–15:00', '18:00–23:00'] },
  { dia: 'Quinta-feira', faixas: ['11:00–15:00', '18:00–23:00'] },
  { dia: 'Sexta-feira', faixas: ['11:00–15:00', '18:00–23:00'] },
  { dia: 'Sábado', faixas: ['11:00–15:00', '18:00–23:00'] },
  { dia: 'Domingo', faixas: ['11:00–15:00'] },
];

// Preencher somente quando o endereço oficial for confirmado.
export const endereco = '';

export interface Produto {
  id: string;
  nome: string;
  categoria: string;
  descricao: string;
  preco: number;
  imagem: string;
}

export const produtos: Produto[] = [
  {
    id: '1',
    nome: '[substituir]',
    categoria: 'Doces',
    descricao: '[substituir]',
    preco: 0,
    imagem: '/produtos/placeholder-1.jpg',
  },
  {
    id: '2',
    nome: '[substituir]',
    categoria: 'Doces',
    descricao: '[substituir]',
    preco: 0,
    imagem: '/produtos/placeholder-2.jpg',
  },
  {
    id: '3',
    nome: '[substituir]',
    categoria: 'Salgados',
    descricao: '[substituir]',
    preco: 0,
    imagem: '/produtos/placeholder-3.jpg',
  },
];

export const categorias = [
  'Todos',
  ...Array.from(new Set(produtos.map((produto) => produto.categoria))),
];

export function nomeVisivel(produto: Produto) {
  return produto.nome.startsWith('[') ? 'Produto a confirmar' : produto.nome;
}

export function descricaoVisivel(produto: Produto) {
  return produto.descricao.startsWith('[')
    ? 'Descrição e disponibilidade serão atualizadas em breve.'
    : produto.descricao;
}

export function precoVisivel(preco: number) {
  if (preco <= 0) return 'Consulte no iFood';

  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(preco);
}
