'use client';

import { useEffect, useState } from 'react';

import { FlowButton } from '@/components/ui/flow-button';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { categorias } from '@/lib/site-data';
import { cn } from '@/lib/utils';

export function SiteHeader() {
  const [isSolid, setIsSolid] = useState(false);

  useEffect(() => {
    let frame = 0;

    const updateHeader = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        setIsSolid(window.scrollY > Math.min(window.innerHeight * 0.58, 520));
      });
    };

    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });
    window.addEventListener('resize', updateHeader);

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', updateHeader);
      window.removeEventListener('resize', updateHeader);
    };
  }, []);

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 border-b transition-[background-color,border-color,backdrop-filter] duration-300',
        isSolid
          ? 'border-gold-light/55 bg-background/92 backdrop-blur-md'
          : 'border-transparent bg-transparent',
      )}
    >
      <div className="mx-auto flex h-[4.75rem] w-[min(1180px,calc(100%-32px))] items-center justify-between gap-3">
        <a
          href="#inicio"
          aria-label="Delícias Rosicleia — voltar ao início"
          className="shrink-0 font-heading text-xl leading-none tracking-[-0.035em] sm:text-2xl"
        >
          <span className="sm:hidden">DR</span>
          <span className="hidden sm:inline">Delícias Rosicleia</span>
        </a>

        <nav aria-label="Categorias do cardápio" className="hidden lg:block">
          <ul className="flex items-center gap-6">
            {categorias.slice(1).map((categoria) => (
              <li key={categoria}>
                <a
                  href="#filtros-cardapio"
                  onClick={() => {
                    window.dispatchEvent(
                      new CustomEvent('catalog-category-change', {
                        detail: categoria,
                      }),
                    );
                  }}
                  className="text-sm font-semibold text-muted transition-colors hover:text-foreground"
                >
                  {categoria}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#horarios"
                className="text-sm font-semibold text-muted transition-colors hover:text-foreground"
              >
                Horários
              </a>
            </li>
          </ul>
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          <ThemeToggle />
          <FlowButton
            text="iFood"
            className="min-h-11 px-5 py-2.5 sm:px-6"
          />
        </div>
      </div>
    </header>
  );
}
