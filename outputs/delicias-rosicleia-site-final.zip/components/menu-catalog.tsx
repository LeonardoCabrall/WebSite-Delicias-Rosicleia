'use client';

import { useEffect, useMemo, useState } from 'react';
import { Search, SearchX, X } from 'lucide-react';
import Image from 'next/image';

import { FlowButton } from '@/components/ui/flow-button';
import { Input } from '@/components/ui/input';
import {
  categorias,
  descricaoVisivel,
  nomeVisivel,
  precoVisivel,
  produtos,
  type Produto,
} from '@/lib/site-data';
import { cn } from '@/lib/utils';

function normalizar(texto: string) {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR')
    .trim();
}

function ProductCard({ produto }: { produto: Produto }) {
  const nome = nomeVisivel(produto);

  return (
    <article className="group overflow-hidden rounded-[6px] border border-gold-light/70 bg-surface">
      <div className="aspect-[4/3] overflow-hidden border-b border-gold-light/65 bg-gold-light/20">
        <Image
          src={produto.imagem}
          alt={`Imagem provisória de ${nome.toLocaleLowerCase('pt-BR')}`}
          width="1200"
          height="900"
          loading="lazy"
          sizes="(max-width: 639px) 100vw, (max-width: 1023px) 50vw, 33vw"
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.035] motion-reduce:transition-none"
        />
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-[1.05rem] font-semibold leading-6">{nome}</h3>
          <span className="shrink-0 rounded-full bg-gold-light/45 px-2.5 py-1 text-xs font-bold text-foreground">
            {produto.categoria}
          </span>
        </div>
        <p className="mt-3 min-h-12 text-sm leading-6 text-muted">
          {descricaoVisivel(produto)}
        </p>
        <p className="mt-5 border-t border-gold-light/65 pt-4 text-sm font-bold text-gold-ink">
          {precoVisivel(produto.preco)}
        </p>
      </div>
    </article>
  );
}

export function MenuCatalog() {
  const [busca, setBusca] = useState('');
  const [categoriaAtiva, setCategoriaAtiva] = useState('Todos');

  useEffect(() => {
    const selecionarCategoria = (event: Event) => {
      const categoria = (event as CustomEvent<string>).detail;

      if (categorias.includes(categoria)) {
        setCategoriaAtiva(categoria);
      }
    };

    window.addEventListener('catalog-category-change', selecionarCategoria);

    return () => {
      window.removeEventListener('catalog-category-change', selecionarCategoria);
    };
  }, []);

  const produtosFiltrados = useMemo(() => {
    const termo = normalizar(busca);

    return produtos.filter((produto) => {
      const correspondeCategoria =
        categoriaAtiva === 'Todos' || produto.categoria === categoriaAtiva;
      const textoPesquisavel = normalizar(
        [
          nomeVisivel(produto),
          descricaoVisivel(produto),
          produto.categoria,
        ].join(' '),
      );

      return correspondeCategoria && textoPesquisavel.includes(termo);
    });
  }, [busca, categoriaAtiva]);

  return (
    <section
      id="catalogo"
      aria-labelledby="catalogo-title"
      className="bg-background py-20 sm:py-24"
    >
      <div className="mx-auto w-[min(1180px,calc(100%-32px))]">
        <div className="grid gap-8 border-b border-gold-light/75 pb-10 lg:grid-cols-[1fr_1.2fr] lg:items-end">
          <div>
            <h2
              id="catalogo-title"
              className="font-heading text-[clamp(2.2rem,4.4vw,3.4rem)] leading-tight tracking-[-0.04em]"
            >
              Cardápio em preparação
            </h2>
            <p className="mt-4 max-w-[60ch] leading-7 text-muted">
              A estrutura já está pronta para receber os nomes, descrições,
              preços e fotos oficiais da Delícias Rosicleia.
            </p>
          </div>

          <label className="relative block" htmlFor="busca-cardapio">
            <span className="sr-only">Buscar produto no cardápio</span>
            <Search
              aria-hidden="true"
              className="pointer-events-none absolute left-4 top-1/2 z-10 size-[18px] -translate-y-1/2 text-gold-ink"
            />
            <Input
              id="busca-cardapio"
              type="search"
              value={busca}
              onChange={(event) => setBusca(event.target.value)}
              placeholder="Busque por nome, descrição ou categoria"
              className="h-14 rounded-[5px] border-gold-light bg-surface pl-12 pr-12 text-base placeholder:text-muted focus-visible:border-gold-dark focus-visible:ring-gold/25"
            />
            {busca ? (
              <button
                type="button"
                onClick={() => setBusca('')}
                aria-label="Limpar busca"
                className="absolute right-1.5 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full text-muted transition-colors hover:bg-gold-light/40 hover:text-foreground"
              >
                <X aria-hidden="true" className="size-4" />
              </button>
            ) : null}
          </label>
        </div>

        <div id="filtros-cardapio" className="scroll-mt-28 pt-7">
          <fieldset className="flex gap-2 overflow-x-auto pb-3">
            <legend className="sr-only">Filtrar por categoria</legend>
            {categorias.map((categoria) => {
              const ativa = categoria === categoriaAtiva;

              return (
                <button
                  key={categoria}
                  type="button"
                  aria-pressed={ativa}
                  onClick={() => setCategoriaAtiva(categoria)}
                  className={cn(
                    'min-h-11 shrink-0 rounded-full border px-5 py-2 text-sm font-bold transition-colors',
                    ativa
                      ? 'border-gold bg-gold text-[#2b2216]'
                      : 'border-gold-light bg-surface text-muted hover:border-gold-dark hover:text-foreground',
                  )}
                >
                  {categoria}
                </button>
              );
            })}
          </fieldset>

          <output aria-live="polite" className="mt-3 block text-sm text-muted">
            {produtosFiltrados.length}{' '}
            {produtosFiltrados.length === 1 ? 'item encontrado' : 'itens encontrados'}
          </output>
        </div>

        {produtosFiltrados.length ? (
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {produtosFiltrados.map((produto) => (
              <ProductCard key={produto.id} produto={produto} />
            ))}
          </div>
        ) : (
          <div className="mt-8 grid min-h-72 place-items-center rounded-[6px] border border-gold-light bg-surface px-6 text-center">
            <div>
              <SearchX aria-hidden="true" className="mx-auto size-8 text-gold-ink" />
              <h3 className="mt-4 text-lg font-semibold">Nenhum item por aqui</h3>
              <p className="mt-2 max-w-md text-sm leading-6 text-muted">
                Tente outra palavra ou escolha a categoria “Todos”.
              </p>
            </div>
          </div>
        )}

        <div className="mt-10 flex flex-col items-start justify-between gap-5 border-t border-gold-light/75 pt-8 sm:flex-row sm:items-center">
          <p className="max-w-[58ch] text-sm leading-6 text-muted">
            Disponibilidade e valores finais são sempre confirmados no iFood.
          </p>
          <FlowButton text="Ver cardápio no iFood" />
        </div>
      </div>
    </section>
  );
}
