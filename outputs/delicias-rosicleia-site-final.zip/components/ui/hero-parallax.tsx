'use client';

import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from '@studio-freight/lenis';

import { FlowButton } from '@/components/ui/flow-button';

export function HeroParallax() {
  const parallaxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const triggerElement = parallaxRef.current?.querySelector(
      '[data-parallax-layers]',
    );
    const prefersReducedMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)',
    ).matches;

    if (prefersReducedMotion) return;

    if (triggerElement) {
      const mobileFactor = window.matchMedia('(max-width: 767px)').matches
        ? 0.5
        : 1;
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: triggerElement,
          start: '0% 0%',
          end: '100% 0%',
          scrub: 0,
        },
      });

      const layers = [
        { layer: '1', yPercent: 70 * mobileFactor },
        { layer: '2', yPercent: 55 * mobileFactor },
        { layer: '3', yPercent: 40 * mobileFactor },
        { layer: '4', yPercent: 10 * mobileFactor },
      ];

      layers.forEach((layerObj, idx) => {
        tl.to(
          triggerElement.querySelectorAll(
            `[data-parallax-layer="${layerObj.layer}"]`,
          ),
          { yPercent: layerObj.yPercent, ease: 'none' },
          idx === 0 ? undefined : '<',
        );
      });
    }

    const lenis = new Lenis();
    lenis.on('scroll', () => ScrollTrigger.update());
    const updateLenis = (time: number) => {
      lenis.raf(time * 1000);
    };
    gsap.ticker.add(updateLenis);
    gsap.ticker.lagSmoothing(0);

    return () => {
      ScrollTrigger.getAll().forEach((st) => st.kill());
      if (triggerElement) {
        gsap.killTweensOf(triggerElement);
      }
      gsap.ticker.remove(updateLenis);
      lenis.destroy();
    };
  }, []);

  return (
    <div className="parallax" ref={parallaxRef}>
      <section id="inicio" className="parallax__header" aria-labelledby="hero-title">
        <div className="parallax__visuals">
          <div data-parallax-layers className="parallax__layers">
            <div
              aria-hidden="true"
              data-parallax-layer="1"
              className="absolute inset-0 bg-[linear-gradient(145deg,var(--hero-wash)_0%,var(--background)_43%,var(--surface)_100%)]"
            >
              <div className="hero-grain absolute inset-0 opacity-35" />
            </div>

            <div
              aria-hidden="true"
              data-parallax-layer="2"
              className="absolute inset-0 overflow-hidden"
            >
              <span className="absolute -left-[14vw] top-[13vh] aspect-square w-[min(58vw,700px)] rounded-full border border-gold/55 bg-gold/10" />
              <span className="absolute -right-[13vw] bottom-[-31vw] aspect-square w-[min(70vw,840px)] rounded-full border border-gold-dark/45 bg-gold/15" />
              <span className="absolute right-[8vw] top-[20vh] hidden size-48 rotate-12 border border-gold/55 bg-surface/25 lg:block" />
            </div>

            <div
              data-parallax-layer="3"
              className="absolute inset-x-0 top-[22vh] z-10 mx-auto w-[min(1180px,calc(100%-32px))]"
            >
              <p className="mb-4 text-sm font-semibold text-muted">
                Comida caseira feita com cuidado
              </p>
              <h1
                id="hero-title"
                className="max-w-[11ch] font-heading text-[clamp(3.75rem,9.4vw,7.8rem)] leading-[0.84] tracking-[-0.065em]"
              >
                Delícias
                <span className="block pl-[0.28em] text-gold-dark">Rosicleia</span>
              </h1>
            </div>

            <div
              data-parallax-layer="4"
              className="absolute inset-x-0 bottom-[clamp(2.25rem,8vh,5.5rem)] z-20 mx-auto flex w-[min(1180px,calc(100%-32px))] flex-col items-start justify-between gap-7 md:flex-row md:items-end"
            >
              <p className="max-w-[56ch] text-[clamp(1rem,1.55vw,1.12rem)] leading-7 text-muted">
                Sabores com jeito de casa, apresentados com carinho. Conheça o
                cardápio e finalize seu pedido com segurança pelo iFood.
              </p>
              <FlowButton className="shrink-0 bg-background/45 backdrop-blur-sm" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
