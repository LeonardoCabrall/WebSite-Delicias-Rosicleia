import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import test from 'node:test';

const siteUrl = process.env.SITE_URL ?? 'http://localhost:3000/';
const ifoodUrl =
  'https://www.ifood.com.br/delivery/sao-paulo-sp/delicias-rosicleia-conjunto-habitacional-brigadeiro-faria-lima/47694be2-a16e-49d2-9ba6-fbdaa2efe570?utm_medium=share';
const expectedTitle =
  'Delícias Rosicleia — comida caseira, direto no seu iFood';
const expectedDescription =
  'Comida feita à moda da casa, com ingredientes selecionados. Veja o cardápio completo e peça pelo iFood.';

let html = '';

function luminanciaRelativa(hex) {
  const canais = hex
    .replace('#', '')
    .match(/../g)
    .map((canal) => Number.parseInt(canal, 16) / 255)
    .map((canal) =>
      canal <= 0.04045
        ? canal / 12.92
        : ((canal + 0.055) / 1.055) ** 2.4,
    );

  return canais[0] * 0.2126 + canais[1] * 0.7152 + canais[2] * 0.0722;
}

function contraste(corA, corB) {
  const luzA = luminanciaRelativa(corA);
  const luzB = luminanciaRelativa(corB);

  return (Math.max(luzA, luzB) + 0.05) / (Math.min(luzA, luzB) + 0.05);
}

test.before(async () => {
  const response = await fetch(siteUrl);
  assert.equal(response.status, 200);
  html = await response.text();
});

test('entrega idioma, título e descrição corretos', () => {
  assert.match(html, /<html[^>]+lang="pt-BR"/);
  assert.ok(html.includes(expectedTitle));
  assert.ok(html.includes(expectedDescription));
});

test('todas as CTAs renderizadas usam o link externo seguro do iFood', () => {
  const anchors = html.match(/<a\b[^>]*>/g) ?? [];
  const ifoodAnchors = anchors.filter((anchor) => anchor.includes(ifoodUrl));

  assert.ok(ifoodAnchors.length >= 4);
  for (const anchor of ifoodAnchors) {
    assert.match(anchor, /target="_blank"/);
    assert.match(anchor, /rel="noopener noreferrer"/);
  }
  assert.doesNotMatch(html, />\s*(Carrinho|Checkout)\s*</i);
});

test('JSON-LD contém 12 faixas e nenhum endereço inventado', () => {
  const match = html.match(
    /<script type="application\/ld\+json">([^<]+)<\/script>/,
  );
  assert.ok(match, 'JSON-LD não encontrado');

  const data = JSON.parse(match[1]);
  assert.equal(data['@type'], 'FoodEstablishment');
  assert.equal(data.name, 'Delícias Rosicleia');
  assert.equal(data.url, ifoodUrl);
  assert.equal(data.openingHoursSpecification.length, 12);
  assert.equal('address' in data, false);
});

test('assets provisórios e cartão social existem localmente', async () => {
  const assets = [
    'public/og.png',
    'public/produtos/placeholder-1.jpg',
    'public/produtos/placeholder-2.jpg',
    'public/produtos/placeholder-3.jpg',
  ];

  await Promise.all(assets.map((asset) => access(join(process.cwd(), asset))));
});

test('hero preserva reduced motion e limpeza de animação', async () => {
  const [hero, styles] = await Promise.all([
    readFile(join(process.cwd(), 'components/ui/hero-parallax.tsx'), 'utf8'),
    readFile(join(process.cwd(), 'app/globals.css'), 'utf8'),
  ]);

  assert.ok(hero.includes('prefers-reduced-motion: reduce'));
  assert.ok(hero.includes('ScrollTrigger.getAll().forEach'));
  assert.ok(hero.includes('gsap.killTweensOf(triggerElement)'));
  assert.ok(hero.includes('gsap.ticker.remove(updateLenis)'));
  assert.ok(hero.includes('lenis.destroy()'));
  assert.ok(styles.includes('@media (prefers-reduced-motion: reduce)'));
});

test('cores de texto pequeno atingem contraste AA no modo claro', () => {
  assert.ok(contraste('#6f521f', '#fbf8f2') >= 4.5);
  assert.ok(contraste('#6f521f', '#fffdf9') >= 4.5);
  assert.ok(contraste('#6b5d45', '#fbf8f2') >= 4.5);
  assert.ok(contraste('#6b5d45', '#fffdf9') >= 4.5);
});

test('header, filtro e tema expõem seus estados acessíveis', async () => {
  const [header, catalogo, tema] = await Promise.all([
    readFile(join(process.cwd(), 'components/site-header.tsx'), 'utf8'),
    readFile(join(process.cwd(), 'components/menu-catalog.tsx'), 'utf8'),
    readFile(join(process.cwd(), 'components/ui/theme-toggle.tsx'), 'utf8'),
  ]);

  assert.ok(header.includes("new CustomEvent('catalog-category-change'"));
  assert.ok(catalogo.includes("addEventListener('catalog-category-change'"));
  assert.ok(catalogo.includes('aria-pressed={ativa}'));
  assert.ok(catalogo.includes('grid size-11'));
  assert.ok(tema.includes('aria-pressed={isDark}'));
  assert.ok(tema.includes("'Ativar tema claro'"));
  assert.ok(tema.includes("'Ativar tema escuro'"));
});
